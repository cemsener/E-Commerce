export interface ProductInt {
  id: number;
  title: string;
  price: number;
  description: string;
  image: string;
  category: string;
}
