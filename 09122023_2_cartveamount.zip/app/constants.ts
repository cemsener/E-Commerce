export const createScreens = () => {
  return {
    xs: "475px",
    sm: "640px",
    md: "768px",
    lg: "1024px",
  };
};
