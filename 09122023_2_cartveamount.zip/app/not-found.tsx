import React from "react";

const notFound = () => {
  return <div>not-found</div>;
};

export default notFound;
